# TODO – Gerador de Conteúdo SCORM (Python + Streamlit)

Este plano segue o escopo do README e organiza o trabalho em etapas objetivas para entregar um gerador de pacotes SCORM a partir de imagens sequenciais (`slide-01.png`, `slide-02.jpeg`, ...), com página HTML navegável, mensagem final dinâmica (Markdown), e empacotamento SCORM.

## 0) Escopo e decisões iniciais
- [x] Versão alvo: SCORM 1.2 (padrão). 2004 como melhoria futura.
- [x] Entrada: imagens `.png` e `.jpeg/.jpg` nomeadas sequencialmente (`slide-NN`), ordenação robusta por número.
- [x] Saída: `index.html` com navegação limpa, botões “Voltar” e “Próximo”, cor do texto dos botões `#0022cb`.
- [x] Pós‑último slide: mensagem de conclusão dinâmica (Markdown → HTML) + botão “Sair”.
- [x] Marcar conclusão no LMS ao finalizar (SCORM 1.2: `cmi.core.lesson_status = completed`).

## 1) Setup do projeto
- [x] Definir estrutura de pastas básica:
  - `app.py` (Streamlit)
  - `scorm/templates/` (Jinja2: `index.html.j2`, `imsmanifest.xml.j2`)
  - `scorm/static/` (`styles.css`, `scorm12.js` – wrapper de API)
  - `scorm/generator.py`, `scorm/packaging.py`, `scorm/images.py`
  - `examples/slides/` (amostras)
- [x] Criar `requirements.txt` (streamlit, jinja2, markdown, pillow, lxml ou xmltodict opcional).
- [x] Configurar `.gitignore` (venv, __pycache__, arquivos temporários/zip).

## 2) Núcleo: leitura e ordenação de slides
- [x] Implementar utilitário para ler arquivos enviados/selecionados e filtrar por regex `^slide-(\\d+)\\.(png|jpe?g)$` (case‑insensitive).
- [x] Ordenar por número capturado (ex.: `slide-01`, `slide-2`, `slide-10`).
- [x] Validar mínimo de 1 slide; reportar feedback amigável no Streamlit.

## 3) Template HTML e navegação
- [x] Criar `index.html.j2` com:
  - [x] Container responsivo e visual clean.
  - [x] Renderização de slides (uma imagem por vez).
  - [x] Botões “Voltar” e “Próximo” (texto com cor `#0022cb`) posicionados abaixo do slide.
  - [x] Suporte a teclas ←/→ e indicador simples de progresso (ex.: `1/10`).
  - [x] Tela de conclusão com área para mensagem (HTML gerado de Markdown) e botão “Sair”.
- [x] Adicionar `styles.css` enxuto (mobile first). 
- [x] Incluir JS para lógica de navegação, troca de slides e exibição da tela final.

## 4) Mensagem final dinâmica (Markdown)
- [x] No Streamlit, usar `st.text_area` para receber o Markdown da mensagem final (valor padrão: “Parabéns, você finalizou este curso!”).
- [x] Converter para HTML (lib `markdown`) e injetar no template com segurança (permitir tags básicas, sanitização leve se necessário).

## 5) Integração SCORM 1.2
- [x] Incluir `scorm12.js` com descoberta da API (`API`/`API_1484_11`) e funções `LMSInitialize`, `LMSSetValue`, `LMSCommit`, `LMSFinish`.
- [x] No `index.html`, ao abrir: chamar `LMSInitialize("")` com tolerância a erro.
- [x] Ao atingir a tela final: `LMSSetValue('cmi.core.lesson_status', 'completed')` + `LMSCommit("")`.
- [x] Botão “Sair”: chamar `LMSFinish("")` e tentar fechar a janela (`window.close()`), mantendo fallback para ambientes sem permissão.

## 6) Manifesto SCORM e empacotamento
- [x] Criar `imsmanifest.xml.j2` (SCORM 1.2) com:
  - [x] Um SCO principal (`index.html`) e metadados básicos (identifier, title).
  - [x] Resource apontando para `index.html` e incluindo todos os assets (imagens, css, js).
- [ ] Implementar gerador que escreve a estrutura final em pasta temporária (ex.: `build/<uuid>`):
  - [ ] `index.html`, `imsmanifest.xml`, `static/`, `slides/`.
- [x] Compactar em `.zip` pronto para upload no LMS (mantendo `imsmanifest.xml` na raiz).

## 7) Interface Streamlit
- [ ] Tela única com seções ou multipáginas simples:
  - [x] Upload de imagens (múltiplos arquivos) via `st.file_uploader(accept_multiple_files=True)`.
  - [x] Campos: Título do curso, Identificador (auto‑gerado se vazio), versão SCORM (1.2 fixa nesta fase), cor dos botões (fixo `#0022cb` por enquanto).
  - [x] Editor da mensagem final (Markdown) com pré‑visualização live (opcional).
  - [x] Pré‑visualização do player final em modal visual (overlay com iframe data URL, compatível com qualquer versão do Streamlit), idêntico ao pacote, assets inline para preview.
  - [x] Botão “Gerar SCORM” → gera zip em memória e disponibiliza `st.download_button`.
- [x] Manter estado com `st.session_state` (ex.: controle de exibição do modal de preview).

## 8) Validação e exemplos
- [ ] Adicionar pasta `examples/slides/` com 3–5 imagens de exemplo nomeadas corretamente.
- [ ] Testar pacote resultante em um LMS de teste (ex.: SCORM Cloud – manual) e ajustar se necessário.
- [ ] Validar que sem LMS a navegação funciona, e as chamadas SCORM falham silenciosamente.

## 9) Qualidade e robustez
- [ ] Tratamento de erros e mensagens amigáveis no Streamlit.
- [ ] Sanitização do HTML gerado a partir do Markdown (permitir apenas tags seguras básicas, sem scripts).
- [ ] Logs mínimos em console para debug (opcional).

## 10) Roadmap (melhorias futuras)
- [ ] Suporte SCORM 2004 (completion_status, success_status, `API_1484_11`).
- [ ] Reordenação de slides no UI (drag‑and‑drop) e edição de títulos.
- [ ] Temas de cores e fontes; modo alto contraste.
- [ ] Barra de progresso visual; miniaturas de slides; modo tela cheia.
- [ ] Multilíngue (PT/EN) para interface e botões no player.
- [ ] Inclusão de áudio por slide; tempo mínimo por slide; bloqueios de navegação.

## 11) Entregáveis
- [x] App executável com `streamlit run app.py`.
- [x] `TODO.md` atualizado com status das etapas.
- [ ] Pacote `.zip` SCORM gerado e válido no LMS alvo.
